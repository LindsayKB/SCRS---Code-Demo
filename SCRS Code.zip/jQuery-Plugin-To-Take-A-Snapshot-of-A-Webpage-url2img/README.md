url2img
=======

Simple, lightweight jQuery plugin - uses Google Page Insights API to get website screenshots
