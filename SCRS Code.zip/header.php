<?php
 $today = date("F j, Y");
?> 
 <div class="one columns">&nbsp;</div>
  <div class="two columns"><center><h1>SCRS</h1></center></div>
  <div class="three columns"><center><h1><?php echo $today ?></h1></center></div>
  <div class="five columns"><center><a href="logout.php"><button>Log Out</button></a> <a href="list.php"><button>List of Clients</button></a> <a href="edit.php"><button>Edit Profiles</button></a> <a href="archive.php"><button>Archive</button></a></center></div>
  <div class="one columns">&nbsp;</div>