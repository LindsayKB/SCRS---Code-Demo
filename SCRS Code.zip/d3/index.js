export {
  save,
  embedRasterImages,
} from './src/d3-save-svg';
