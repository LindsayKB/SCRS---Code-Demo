function goBack() {
    window.history.back();
}

$('#close-description').click(function() {
	alert("It worked!");
	 
});