<?php

$dbhost = 'mysql6.000webhost.com';
$dbuser = 'a8990775_admin';
$dbpassword = 'Abcd1234!';
$database = 'a8990775_scrs';
?>