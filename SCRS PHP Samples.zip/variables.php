<script>
var weakWeakCount = <?= json_encode($weakWeakCount) ?>;
</script>