<?php
class GrabzItWaterMark
{
  public $Identifier;
  public $XPosition;
  public $YPosition;
  public $Format;
}
?>