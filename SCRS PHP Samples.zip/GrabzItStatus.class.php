<?php
class GrabzItStatus
{
  public $Processing;
  public $Cached;
  public $Expired;
  public $Message;
}
?>